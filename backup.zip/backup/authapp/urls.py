from django.conf.urls import url
# import the views
from . import views

urlpatterns = [
    # use url to display the home page
    #url(r'^$', views.index, name='home'),
    # use url for login
    #url(r'^login/$', views.user_login, name='login'),
    # To view the user profile.
    url(r'^@(?P<username>[\w-]+)/$', views.UserProfileView.as_view(), name='profile'),
    # To view the user comments.
    url(r'^@(?P<username>[\w-]+)/comments/$', views.UserComments.as_view(), name='user_comments'),
    # when you update the profile then it will goes directly to userprofile
    url(r'^accounts/profile/$', views.profile_redirector, name='user_profile'),
    # To see the user update view form
    url(r'^accounts/profile/update/$', views.UserProfileUpdateView.as_view(), name='user_profile_update'),
]
