import uuid

from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.views.generic import DetailView, ListView, UpdateView
from django.views.generic.detail import SingleObjectMixin
from django.db.models import Prefetch

from .models import UserProfile
from comments.models import Comment
from .forms import UserForm, UserProfileForm

# Create your views here.
#def index(request):
#    return render(request, 'home.html')

#def user_login(request):
#    return render(request, 'account/login.html')

# It shows the userprofile page with the all user post using the get_queryset function
class UserProfileView(DetailView):
    template_name = 'authapp/user_profile.html'
    model = UserProfile
    context_object_name = 'profile'
    slug_url_kwarg = 'username'
    slug_field = 'user__username'

    def get_queryset(self):
        queryset = self.model.objects.select_related(
            'user', 'user__blog').prefetch_related('user__posts')
        return queryset


@login_required
def profile_redirector(request):
    return redirect('authapp:profile', username=request.user.username)

# It show the user comments the post using get function it shows those post have comments
class UserComments(SingleObjectMixin, ListView):
    template_name = 'authapp/user_comments.html'
    model = UserProfile
    slug_url_kwarg = 'username'
    slug_field = 'user__username'

    def get(self, request, *args, **kwargs):
        self.object = self.get_object(
            queryset=self.model.objects.select_related(
                'user', 'user__blog').prefetch_related(
                    Prefetch(
                        'user__comments',
                        queryset=Comment.objects.select_related(
                            'post').filter(is_public=True)
                    ),
                    'user__posts')
            )
        return super(UserComments, self).get(request, *args, **kwargs)

    # This function shows the data of comments with who post the comments profile
    def get_context_data(self, **kwargs):
        context = super(UserComments, self).get_context_data(**kwargs)
        context['profile'] = self.object
        context['comments'] = self.get_queryset()
        return context

    # This function used to show all comments for perticular post
    def get_queryset(self):
        qs = self.object.user.comments.all()
        return qs

# This class shows the userprofileupadteviews with get_context_data, get, post and get_object finction
class UserProfileUpdateView(UpdateView):

    template_name = 'authapp/edit_profile.html'
    form_class = UserForm
    form_class_2 = UserProfileForm

    # This function shows the data of user
    def get_context_data(self, **kwargs):
        context = super(UserProfileUpdateView, self).get_context_data(**kwargs)
        if 'form' not in context:
            context['form'] = self.form_class(instance=self.request.user)
        if 'form2' not in context:
            context['form2'] = self.form_class_2(instance=self.request.user.profile)  # noqa
        return context

    # This function gets the object data of user
    def get(self, request, *args, **kwargs):
        super(UserProfileUpdateView, self).get(request, *args, **kwargs)
        self.object = self.get_object()
        form = self.form_class(instance=self.request.user)
        form2 = self.form_class_2(instance=self.request.user.profile)

        return self.render_to_response(self.get_context_data(
            form=form, form2=form2
        ))

    # This function post the object data of user
    def post(self, request, *args, **kwargs):
        self.object = self.get_object()
        form = self.form_class(request.POST, instance=self.request.user)
        form2 = self.form_class_2(request.POST, request.FILES,
                                  instance=self.request.user.profile)

        if form.is_valid() and form2.is_valid():
            form.save()
            data = form2.save(commit=False)
            if request.FILES.get('avatar', None):
                data.avatar = request.FILES['avatar']
                data.avatar.name = '{0}_p.jpg'.format(str(uuid.uuid4()))
            data.save()
            return redirect('authapp:user_profile')
        else:
            return self.render_to_response(
                self.get_context_data(form=form, form2=form2)
                )

    # This function get the data of user and store it.
    def get_object(self, queryset=None):
        return self.request.user
