from django.db import models
from django.conf import settings
from django.core.urlresolvers import reverse_lazy
# import autoslug to fill the autoslug value
from autoslug import AutoSlugField
# import simplemde for image uploade
from simplemde.fields import SimpleMdeField

# Create Blog model with following fields
class Blog(models.Model):
    title = models.CharField(max_length=100)
    tag_line = models.CharField(max_length=50)
    short_description = models.TextField(max_length=255)

    created = models.DateTimeField(auto_now_add=True)
    last_modified = models.DateTimeField(auto_now=True)

    # one to one because an author can only have one blog (as of now)
    author = models.OneToOneField(settings.AUTH_USER_MODEL)

    is_public = models.BooleanField(default=True)
    is_deleted = models.BooleanField(default=False)

    def __str__(self):
        return self.title

    # get_absolute_url function return the user_blog with arguments author username
    def get_absolute_url(self):
        target = reverse_lazy('blog:user_blog', args=[self.author.username])
        return target

# Create PostQueryset for understanding the post is selected in Published or in Draft
class PostQueryset(models.QuerySet):
    """
    QuerySet class for Post model. Works like a manager.
    Useful for method chaining.
    """
    def published(self):
        return self.filter(status='p')

    def draft(self):
        return self.filter(status='d')

# Create the Post models with following fields
class Post(models.Model):

    STATUS_CHOICES = (
        ('d', 'Draft'),
        ('p', 'Published'),
    )

    blog = models.ForeignKey(Blog, related_name='posts')

    title = models.CharField(max_length=150)
    summary = models.CharField(max_length=255, blank=True)
    content = SimpleMdeField()

    slug = AutoSlugField(populate_from='title', unique_with=['blog'],
                         editable=True)

    cover = models.ImageField(blank=True, upload_to='uploads/%Y/%m/%d/')

    tags = models.ManyToManyField('Tag', related_name='posts', blank=True)

    created = models.DateTimeField(auto_now_add=True)
    last_modified = models.DateTimeField(auto_now=True)

    author = models.ForeignKey(settings.AUTH_USER_MODEL, related_name='posts')

    status = models.CharField(choices=STATUS_CHOICES, max_length=1,
                              default='d')
    view_count = models.IntegerField(default=0)

    objects = PostQueryset.as_manager()

    def __str__(self):
        return self.title

    def is_published(self):
        return self.status == 'p'

    def is_draft(self):
        return self.status == 'd'

    # get_absolute_url function return the post_detail with arguments author username
    def get_absolute_url(self):
        target = reverse_lazy('blog:post_detail',
                              args=[self.author.username, self.slug])
        return target

    def add_view(self):
        if self.view_count is not None:
            self.view_count += 1
        else:
            self.view_count = 0

    class Meta(object):
        ordering = ('-created', )

# Create the Tag model with following fields.
class Tag(models.Model):
    name = models.CharField(max_length=30)
    slug = AutoSlugField(populate_from='name', editable=True, unique=True)

    def __str__(self):
        return self.name

    # get_absolute_url function return the tagged_posts_list with argument slug
    def get_absolute_url(self):
        target = reverse_lazy('blog:tagged_posts_list', args=[self.slug])
        return target
