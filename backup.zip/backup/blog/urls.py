from django.conf.urls import url
# import the views
from . import views

urlpatterns = [
    # use url to display the home page with all active blogs
    url(r'^$', views.HomeTemplateView.as_view(), name='home'),
    # use url to display the user blog profile
    url(r'^@(?P<username>[\w-]+)/blog/$', views.BlogDetail.as_view(), name='user_blog'),  # noqa
    # use url to display the post detail with the data using url path is username/blogname with slug
    url(r'^@(?P<username>[\w-]+)/blog/(?P<slug>[\w-]+)/$',
        views.PostDetailView.as_view(), name='post_detail'),

    # use url to fill autocomplete when you click on the tag name
    url(r'^tags/$', views.TagAutoComplete.as_view(), name='tag_autocomplete'),
    # use url for display the tag name when you create the form
    url(r'^tags/(?P<tag>[\w-]+)/$', views.TagggedPostsList.as_view(),
        name='tagged_posts_list'),

    # use url to start the blog posting
    url(r'^blog/start/$', views.BlogCreateView.as_view(), name='blog_create'),
    # use url to update the blog post
    url(r'^blog/update/$', views.BlogUpdateView.as_view(), name='blog_update'),
    # use url for to view the blog comments
    url(r'^blog/comments/$', views.BlogComments.as_view(), name='blog_comments'),  # noqa

    # use url to create the post
    url(r'^write/$', views.PostCreateView.as_view(), name='post_create'),
    # use url to Update the post using slug name defined
    url(r'^update/(?P<slug>[\w-]+)/$', views.PostUpdateView.as_view(), name='post_update'),  # noqa
    # use url to delete the post using slug name defined
    url(r'^delete/(?P<slug>[\w-]+)/$', views.PostDeleteView.as_view(), name='post_delete'),  # noqa
    # use url for user post list view
    url(r'^posts/$', views.UserPostsList.as_view(), name='user_posts'),
    # add url for female list
    url(r'^tags/tag/$', views.FemalePostsList.as_view(), name='tag_posts_list'),
    #url(r'^tags/female/$', views.FemalePostsList.as_view(), name='female_posts_list'),
    # add url for male list
    #url(r'^tags/male/$', views.MalePostsList.as_view(), name='male_posts_list'),
    #url(r'^tags/kids/$', views.KidPostsList.as_view(), name='kid_posts_list'),
    #url(r'^tags/hair/$', views.HairPostsList.as_view(), name='hair_posts_list'),
    #url(r'^tags/bones/$', views.BonePostsList.as_view(), name='bone_posts_list'),
    #url(r'^tags/skin/$', views.SkinPostsList.as_view(), name='skin_posts_list'),
]
