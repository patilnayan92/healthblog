from django import forms

from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout, Submit
from crispy_forms.bootstrap import StrictButton
# dal is used for autocomplete the form
from dal import autocomplete
# import the blog models.py file
from .models import Blog, Post, Tag

OPTIONS = [
        ("0", "*ALL"),
        ("1", "Male"),
        ("2", "Female"),
        ("3", "Skin"),
        ("4", "Bones"),
        ("5", "Kids"),
        ("6", "Hair"),
        ]

# Create the BlogForm using Blog Model
class BlogForm(forms.ModelForm):

    class Meta(object):
        model = Blog
        fields = ['title', 'tag_line', 'short_description', 'is_public']

    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user')
        super(BlogForm, self).__init__(*args, **kwargs)

        # a little housekeeping
        self.fields['is_public'].label = 'Publicly visible'
        self.fields['short_description'].widget.attrs['class'] = 'materialize-textarea'  # noqa

        # making forms crispy
        self.helper = FormHelper(self)
        self.helper.layout = Layout(
            'title', 'tag_line', 'short_description', 'is_public',
            StrictButton(
                'Create a Blog', type='submit',
            )
        )

    def save(self, commit=True):
        save_data = super(BlogForm, self).save(commit=False)
        save_data.author = self.user
        save_data.save()
        return save_data

# Create the TagCreateField using Tag Model
class TagCreateField(autocomplete.CreateModelMultipleField):
    def create_value(self, value):
        return Tag.objects.create(name=value).pk

# Create the PostForm using Post Model
class PostForm(forms.ModelForm):
    """tags = TagCreateField(
        queryset=Tag.objects.all(),
        widget=autocomplete.ModelSelect2Multiple(url='blog:tag_autocomplete'),
        required=False,
        )"""
    tags = forms.MultipleChoiceField(
            choices=OPTIONS,
            initial='1',
            widget=forms.SelectMultiple,
            required=True,
            label='tags',
        )

    class Meta(object):
        model = Post
        fields = ['title', 'slug', 'cover', 'content', 'summary', 'tags']

    # initialize the form
    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user')
        super(PostForm, self).__init__(*args, **kwargs)
        self.fields['slug'].required = False
        self.fields['slug'].label = 'Slug'
        self.fields['cover'].label = 'Post cover (optional)'
        self.fields['content'].label = ''
        # making forms crispy
        self.helper = FormHelper(self)
        self.helper.include_media = False
        self.helper.add_input(Submit(
            'draft', 'draft',
            css_class='btn orange btn-large right waves-effect waves-light'))
        self.helper.add_input(Submit(
            'publish', 'publish',
            css_class='btn blue btn-large right waves-effect waves-light'))

    # used clean function for clean the data in form
    def clean(self):
        cleaned_data = super(PostForm, self).clean()
        if 'publish' in self.data:
            cleaned_data['status'] = 'p'
        else:
            cleaned_data['status'] = 'd'
        return cleaned_data

    # save function save the all fillings details in form
    def save(self, commit=True):
        save_data = super(PostForm, self).save(commit=False)
        save_data.author = self.user
        save_data.blog = self.user.blog
        save_data.status = self.cleaned_data['status']
        save_data.save()
        return save_data
