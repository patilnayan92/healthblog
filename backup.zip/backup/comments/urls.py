from django.conf.urls import url
# import views from comments app
from .views import CommentCreateView

urlpatterns = [
    # Use url to create comments for the post
    url(r'^post/$', CommentCreateView.as_view(), name='post'),
]
