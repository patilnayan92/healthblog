import json
from django.shortcuts import render
from django.views.generic import CreateView
from django.views.decorators.http import require_POST
from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import login_required
from django.http.response import JsonResponse
# import  comment model form comments app
from .models import Comment
# import CommentForm from comments app
from .forms import CommentForm

# Create CommentCreateView class for create the comment
class CommentCreateView(CreateView):
    model = Comment
    form_class = CommentForm

    @method_decorator([login_required, require_POST])
    def dispatch(self, request, *args, **kwargs):
        return super(CommentCreateView, self).dispatch(request, *args, **kwargs)  # noqa

    def get_form_kwargs(self):
        context = super(CommentCreateView, self).get_form_kwargs()
        context['user'] = self.request.user
        return context

    # fields to display with comments
    @staticmethod
    def comment_dict(comment):
        return {
            'id': comment.id,
            'name': comment.author.first_name,
            'link': comment.author.profile.get_absolute_url(),
            'comment': comment.comment,
            'created': comment.created,
        }

    # Check if form valid then it successfully created comments
    def form_valid(self, form):
        instance = form.save()
        ctx = {'success': True, 'msg': "Comment was created successfully."}
        ctx['data'] = self.comment_dict(instance)
        return JsonResponse(ctx)


    # Check if form invalid then it show msg as given
    def form_invalid(self, form):
        ctx = {'success': False, 'msg': "Failed to post a comment",
               'errors': json.loads(form.errors.as_json())}
        return JsonResponse(ctx)
