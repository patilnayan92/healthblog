from django.apps import AppConfig


class SimplemdeConfig(AppConfig):
    name = 'simplemde'
